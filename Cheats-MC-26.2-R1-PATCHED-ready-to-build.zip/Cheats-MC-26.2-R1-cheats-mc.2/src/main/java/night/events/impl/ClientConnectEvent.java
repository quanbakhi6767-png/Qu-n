/*
 * Decompiled with CFR 0.152.
 */
package night.events.impl;

import night.events.Event;

public class ClientConnectEvent
extends Event {
}

